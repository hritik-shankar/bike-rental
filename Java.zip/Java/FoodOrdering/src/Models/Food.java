package Models;

public class Food {
    private Integer foodId;
    private Integer restaurantId;
    private String name;
    private Double price;

    public Integer getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(Integer restaurantId) {
        this.restaurantId = restaurantId;
    }

    public Integer getFoodId() {
        return foodId;
    }

    public void setFoodId(Integer foodId) {
        this.foodId = foodId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Food(Integer foodId, String name, Double price) {
        this.foodId = foodId;
        this.name = name;
        this.price = price;
    }


}
