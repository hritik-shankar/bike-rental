package Models;

public class Restaurant {
    private Integer restaurantId;
    private String restaurantName;
    private String pincode;

    public Integer getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(Integer restaurantId) {
        this.restaurantId = restaurantId;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public Restaurant(Integer restaurantId, String restaurantName, String pincode) {
        this.restaurantId = restaurantId;
        this.restaurantName = restaurantName;
        this.pincode = pincode;
    }


}
