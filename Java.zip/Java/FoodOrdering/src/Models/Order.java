package Models;

import java.util.List;

public class Order {
    private Integer orderId;
    private Integer restaurantId;
    private Integer userId;
    private List<Integer> foodItems;
    private double amount;

    public List<Integer> getFoodItems() {
        return foodItems;
    }

    public void setFoodItems(List<Integer> foodItems) {
        this.foodItems = foodItems;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(Integer restaurantId) {
        this.restaurantId = restaurantId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Order(Integer orderId, Integer restaurantId, Integer userId, List<Integer> foodItems, double amount) {
        this.orderId = orderId;
        this.restaurantId = restaurantId;
        this.userId = userId;
        this.foodItems = foodItems;
        this.amount = amount;
    }




}
