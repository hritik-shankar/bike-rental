package dao;

import Models.Restaurant;

import java.util.LinkedHashMap;
import java.util.Map;

public class RestaurantDao {
    private final Map<Integer, Restaurant> restaurantMap =  new LinkedHashMap<>();

    public void addRestaurant(Restaurant restaurant){
        System.out.println("REST ID : " + restaurant.getRestaurantId());
        restaurantMap.put(restaurant.getRestaurantId(), restaurant);
    }

    public void removeRestaurant(Integer restaurantId){
        try{
            restaurantMap.remove(restaurantId);
        }
        catch (IllegalArgumentException e){
            System.out.println("Restaurant doesn't exist");
        }
    }

    public Restaurant getRestaurant(Integer restaurantId) {
        Restaurant restaurant = restaurantMap.get(restaurantId);

        if (restaurant == null) {
            throw new IllegalArgumentException("Restaurant with ID " + restaurantId + " not found.");
        }

        return restaurant;
    }
}
