package dao;
import Models.Order;
import java.util.HashMap;
import java.util.Map;

public class OrderDAO {
    private Map<Integer, Order> orders = new HashMap<>();

    public void addOrder(Order order) {
        System.out.println("ORDER ID : " + order.getOrderId());
        orders.put(order.getOrderId(), order);
    }

    public Order getOrderById(int id) {
        return orders.get(id);
    }
}
