package dao;

import Models.Food;
import Models.Restaurant;

import java.util.LinkedHashMap;
import java.util.Map;

public class FoodDao {
    private final Map<Integer, Food> foodMap =  new LinkedHashMap<>();

    public void addFood(Food food){
        System.out.println("FOOD ID : " + food.getFoodId());
        foodMap.put(food.getRestaurantId(), food);
    }

    public void removeFood(Integer foodId){
        try{
            foodMap.remove(foodId);
        }
        catch (IllegalArgumentException e){
            System.out.println("Restaurant doesn't exist");
        }
    }

    public Food getFood(Integer foodId) {
        Food food = foodMap.get(foodId);

        if (food == null) {
            throw new IllegalArgumentException("Restaurant with ID " + foodId + " not found.");
        }

        return food;
    }
}
