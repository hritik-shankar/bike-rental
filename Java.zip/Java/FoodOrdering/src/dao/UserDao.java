package dao;

import Models.User;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class UserDao {
    private Map<Integer, User> userList = new HashMap<>();


    public UserDao() {
    }

    public void addUser(User user){
        userList.put(user.getId(), user);
    }

    public void deleteUser(Integer userId){
        try {
            if(userList.containsKey(userId)){
                userList.remove(userId);
            }
        }
        catch (IllegalArgumentException e){
            System.out.println("User doesn't exists");
        }
    }

    public User getUser(Integer id){
        try{
            if(userList.containsKey(id)){
                return userList.get(id);
            }

        }
        catch (IllegalArgumentException e){
            System.out.println("Error");
        }
        return userList.get(id);
    }


}
