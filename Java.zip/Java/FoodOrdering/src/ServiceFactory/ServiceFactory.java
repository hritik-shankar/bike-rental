package ServiceFactory;

import dao.FoodDao;
import dao.OrderDAO;
import dao.RestaurantDao;
import dao.UserDao;
import service.FoodService;
import service.OrderService;
import service.RestaurantService;
import service.UserService;

public class ServiceFactory {

    private static UserDao userDAO = new UserDao();
    private static RestaurantDao restaurantDAO = new RestaurantDao();
    private static FoodDao foodDAO = new FoodDao();
    private static OrderDAO orderDAO = new OrderDAO();

    public static UserService getUserService() {
        return new UserService(userDAO);
    }

    public static RestaurantService getRestaurantService() {
        return new RestaurantService(restaurantDAO);
    }

    public static FoodService getFoodItemService() {
        return new FoodService(foodDAO);
    }

    public static OrderService getOrderService() {
        return new OrderService(orderDAO, restaurantDAO, userDAO, foodDAO);
    }
}
