import Models.Order;
import Models.User;
import ServiceFactory.ServiceFactory;
import service.FoodService;
import service.OrderService;
import service.RestaurantService;
import service.UserService;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Controller {
    public static void main(String[] args){
        OrderService orderService = ServiceFactory.getOrderService();
        UserService userService = ServiceFactory.getUserService();
        RestaurantService restaurantService = ServiceFactory.getRestaurantService();
        FoodService foodService = ServiceFactory.getFoodItemService();

        userService.registerUser("Hritik","9601");
        userService.registerUser("Pari","97566");

        restaurantService.addRestaurant("Leon","560093");
        restaurantService.addRestaurant("FoodKart", "560035");

        foodService.addFood("Biryani", 500.0);
        foodService.addFood("Chai", 20.0);

        Scanner s = new Scanner(System.in);
        Integer userId = s.nextInt();
        User a = userService.getUser(userId);
        System.out.println(a.getName());
        Integer restId = s.nextInt();
        Integer foodId = s.nextInt();

        List<Integer> foodList = new ArrayList<>();
        foodList.add(foodId);

        orderService.createOrder(restId, foodList, userId);

        Integer orderId = s.nextInt();
        Order order = orderService.getOrder(orderId);

        System.out.println("USER ID : "+order.getUserId() + " Rest ID : " + order.getRestaurantId() + " AMOUNT : " + order.getAmount());
    }
}
