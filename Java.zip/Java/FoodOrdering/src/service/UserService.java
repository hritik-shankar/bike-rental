package service;
import java.util.Random;

import Models.User;
import dao.UserDao;

public class UserService {
    private UserDao userDao;
    Random rand;

    public UserService(UserDao userDao) {
        this.userDao = userDao;
        this.rand = new Random();
    }

    public void registerUser(String name, String phone){
        int userId = rand.nextInt(1000);
        System.out.println(userId);
        User user = new User(userId, name, phone);
        userDao.addUser(user);
    }

    public User getUser(Integer userId){
        return userDao.getUser(userId);
    }
}
