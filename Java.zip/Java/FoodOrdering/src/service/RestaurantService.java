package service;

import dao.RestaurantDao;
import Models.Restaurant;

import java.util.Random;

public class RestaurantService {
    private final RestaurantDao restaurantDAO;
    Random rand;

    public RestaurantService(RestaurantDao restaurantDao) {
        this.restaurantDAO = restaurantDao;
        this.rand = new Random();
    }

    public void addRestaurant(String name, String pincode) {
        Integer restaurantId = rand.nextInt(1000);
        Restaurant restaurant = new Restaurant(restaurantId, name, pincode);
        restaurantDAO.addRestaurant(restaurant);
    }

    public Restaurant getRestaurantDetails(int id) {
        return restaurantDAO.getRestaurant(id);
    }
}
