package service;

import Models.Food;
import Models.Restaurant;
import dao.FoodDao;

import java.util.Random;

public class FoodService {
    private final FoodDao foodDao;
    Random rand;

    public FoodService(FoodDao foodDao) {
        this.foodDao = foodDao;
        this.rand = new Random();
    }

    public void addFood(String name, Double price) {
        Integer foodId = rand.nextInt(1000);
        Food food = new Food(foodId, name, price);
        foodDao.addFood(food);
    }

    public Food getFood(int id) {
        return foodDao.getFood(id);
    }



    }
