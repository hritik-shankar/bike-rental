package service;

import Models.Food;
import Models.Order;
import Models.Restaurant;
import Models.User;
import dao.FoodDao;
import dao.OrderDAO;
import dao.RestaurantDao;
import dao.UserDao;

import java.util.List;
import java.util.Random;

public class OrderService {
    OrderDAO orderDAO;
    Random rand;
    RestaurantDao restaurantDao;
    UserDao userDao;
    FoodDao foodDao;

    public OrderService(OrderDAO orderDAO, RestaurantDao restaurantDao, UserDao userDao, FoodDao foodDao){
        this.orderDAO = orderDAO;
        this.restaurantDao = restaurantDao;
        this.userDao = userDao;
        this.foodDao = foodDao;
        this.rand = new Random();
    }

    public void createOrder(Integer restaurantId, List<Integer> foodId, Integer userId){
        User user = this.userDao.getUser(userId);

        if(user == null){
            throw new IllegalArgumentException("User not found");
        }

//        Food food = this.foodDao.getFood(foodId);
//
//        if(food == null){
//            throw new IllegalArgumentException("Food not found");
//        }

        Restaurant restaurant = this.restaurantDao.getRestaurant(restaurantId);

        if(restaurant == null){
            throw new IllegalArgumentException("Restaurant not found");
        }

        Order order = new Order(rand.nextInt(1000), restaurantId, userId, foodId, 100);
        this.orderDAO.addOrder(order);
    }

    public Order getOrder(Integer orderId){
        Order order = this.orderDAO.getOrderById(orderId);

        if(order == null){
            throw new IllegalArgumentException("Order not found");
        }

        return order;
    }
}
