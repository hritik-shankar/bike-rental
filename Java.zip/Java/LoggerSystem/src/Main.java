import Logger.ErrorMessage;
import Logger.InfoMessage;
import Logger.LogHandlerAbstract;
import Logger.LogProcessor;

public class Main {
    public static void main(String[] args) {
        LogHandlerAbstract logHandlerAbstract = new InfoMessage(new ErrorMessage(null));

        logHandlerAbstract.log(LogProcessor.ERROR, "Hello");
    }
}