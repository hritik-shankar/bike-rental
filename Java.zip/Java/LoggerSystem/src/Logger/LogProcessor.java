package Logger;

public enum LogProcessor {
    INFO, ERROR, DEBUG
}
