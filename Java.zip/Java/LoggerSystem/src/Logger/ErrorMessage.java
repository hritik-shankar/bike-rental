package Logger;

public class ErrorMessage extends LogHandlerAbstract{

    public ErrorMessage(LogHandlerAbstract nextLogger) {
        super(nextLogger);
    }

    public void log(LogProcessor level, String message){
        if(level == LogProcessor.ERROR){
            System.out.println("ERROR : " + message);
            return;
        }

        super.log(level, message);
    }
}