package Logger;

public interface ILogMsgHandler {
    public void message(LogProcessor logProcessor, String message);
    public void nextLogger(ILogMsgHandler nextLogger);
}
