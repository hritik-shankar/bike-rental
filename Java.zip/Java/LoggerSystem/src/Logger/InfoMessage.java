package Logger;

public class InfoMessage extends LogHandlerAbstract{
    public InfoMessage(LogHandlerAbstract nextLogger) {
        super(nextLogger);
    }

    public void log(LogProcessor level, String message){
        if(level == LogProcessor.INFO){
            System.out.println("INFO : " + message);
            return;
        }

        super.log(level, message);
    }
}
