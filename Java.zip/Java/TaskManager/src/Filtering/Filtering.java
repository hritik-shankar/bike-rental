package Filtering;

import Model.Task;

import java.util.List;

public interface Filtering {
    public List<Task> filtering(String keyword);
}
