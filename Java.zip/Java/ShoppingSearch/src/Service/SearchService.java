package Service;

import DAO.MovieDAO;
import Models.Movie;
import Search.SearchFactory;
import Search.SearchStrategy;

import java.util.List;

public class SearchService {
    private MovieDAO movieDAO;
    private SearchFactory searchFactory = new SearchFactory();

    public SearchService(MovieDAO movieDAO){
        this.movieDAO = movieDAO;
    }


    public List<Movie> search(String searchType, String criteria){
        SearchStrategy searchStrategy = searchFactory.searchStrategy(searchType);
        return searchStrategy.search(this.movieDAO, criteria);
    }
}
