package DAO;

import Models.Movie;

import java.util.LinkedHashMap;

public class MovieDAO {
    private LinkedHashMap<Integer, Movie> movies = new LinkedHashMap<>();

    public LinkedHashMap<Integer, Movie> getMovies() {
        return movies;
    }

    public void addMovie(Movie movie) {
        movies.put(movie.getId(), movie);
    }
}
