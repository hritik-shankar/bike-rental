import DAO.MovieDAO;
import Models.Genre;
import Models.Movie;
import Service.SearchService;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        AppConfig appConfig = new AppConfig();
        MovieDAO movieDAO = appConfig.getMovieDao();

        movieDAO.addMovie(new Movie(1, "Movie1", Genre.ACTION, "2025"));
        movieDAO.addMovie(new Movie(2, "Movie2", Genre.ROMANCE, "2024"));

        SearchService searchService = new SearchService(movieDAO);
        List<Movie> movieList = searchService.search("id", "1");

        for(Movie m : movieList){
            System.out.println(m.getName());
        }
    }
}