import DAO.MovieDAO;

public class AppConfig {
    private MovieDAO movieDAO = new MovieDAO();

    public MovieDAO getMovieDao(){
        return movieDAO;
    }
}
