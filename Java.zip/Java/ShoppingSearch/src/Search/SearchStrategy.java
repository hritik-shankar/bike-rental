package Search;

import DAO.MovieDAO;
import Models.Movie;

import java.util.List;

public interface SearchStrategy {
    List<Movie> search(MovieDAO movieDAO, String criteria);
}