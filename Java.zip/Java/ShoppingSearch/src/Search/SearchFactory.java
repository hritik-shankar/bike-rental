package Search;

public class SearchFactory {
    public SearchStrategy searchStrategy(String searchType) {
        switch (searchType.toLowerCase()) {
            case "id":
                return new SearchById();
            case "genre":
                return new SearchByGenre();
            default:
                throw new IllegalArgumentException("Invalid search type");
        }
    }
}
