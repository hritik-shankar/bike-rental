package Search;

import DAO.MovieDAO;
import Models.Movie;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class SearchById implements SearchStrategy {

    @Override
    public List<Movie> search(MovieDAO movieDAO, String criteria) {
        int id = Integer.parseInt(criteria);
        Collectors Collectors = null;
        return movieDAO.getMovies().values().stream()
                .filter(movie -> movie.getId() == id)
                .collect(java.util.stream.Collectors.toList());
    }
}
