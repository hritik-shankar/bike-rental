package Search;

import DAO.MovieDAO;
import Models.Genre;
import Models.Movie;

import java.util.Collections;
import java.util.List;

public class SearchByGenre implements SearchStrategy{
    @Override
    public List<Movie> search(MovieDAO movieDAO, String criteria) {
        Genre genre = Genre.valueOf(criteria.toUpperCase());
        return movieDAO.getMovies().values().stream()
                .filter(movie -> movie.getGenre() == genre)
                .collect(java.util.stream.Collectors.toList());
    }
}
