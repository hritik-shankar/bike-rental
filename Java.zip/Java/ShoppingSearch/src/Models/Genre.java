package Models;

public enum Genre {
    ACTION, ROMANCE, SCIFI
}
