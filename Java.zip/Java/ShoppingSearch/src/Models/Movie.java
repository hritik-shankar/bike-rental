package Models;

public class Movie {
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    private Integer id;
    private String Name;
    private Genre genre;
    private String releaseYear;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public Genre getGenre() {
        return genre;
    }

    public void setGenre(Genre genre) {
        this.genre = genre;
    }

    public String getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(String releaseYear) {
        this.releaseYear = releaseYear;
    }

    public Movie(Integer id, String name, Genre genre, String releaseYear) {
        this.id = id;
        Name = name;
        this.genre = genre;
        this.releaseYear = releaseYear;
    }
}
