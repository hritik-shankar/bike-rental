package com.uditagarwal.exceptions;

public class StorageFullException extends RuntimeException {
}
