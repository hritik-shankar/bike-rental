package com.uditagarwal.policy;

public class LRUEvictionPolicy<Key> implements EvictionPolicy<Key> {
    public void keyAccessed(Object o) {
        // TODO: Implement this.
    }

    public Key evictKey() {
        // TODO: Implement this.
        return null;
    }
}
