package Models;

public interface    RentalObject {
    int getId();
    String getModel();
    double getBaseRate();
}
