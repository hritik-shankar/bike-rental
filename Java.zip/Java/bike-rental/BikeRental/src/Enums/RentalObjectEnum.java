package Enums;

public enum RentalObjectEnum {
    BIKE, SCOOTER;
}
